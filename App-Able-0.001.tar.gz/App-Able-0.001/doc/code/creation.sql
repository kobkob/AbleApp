
--
-- TABLE: Creation
-- 
--  

CREATE TABLE Creation (
  id long int NOT NULL
);
