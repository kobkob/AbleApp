
--
-- TABLE: Prototype
-- 
--  

CREATE TABLE Prototype (
);
ALTER TABLE Prototype ADD CONSTRAINT  FOREIGN KEY () REFERENCES Plan ();
