
--
-- TABLE: Monitor
-- 
--  

CREATE TABLE Monitor (
  id long int NOT NULL
);
