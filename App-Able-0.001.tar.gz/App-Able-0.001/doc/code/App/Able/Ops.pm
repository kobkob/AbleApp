

package App::Able::Ops;


#UML_MODELER_BEGIN_PERSONAL_VARS_Ops

#UML_MODELER_END_PERSONAL_VARS_Ops

use App::Able::Configure;
use App::Able::Release;
use App::Able::Monitor;
use App::Able::Plan;



=head1 OPS



=cut


=head1 PUBLIC ATTRIBUTES

=pod 



=cut


=head1 PUBLIC METHODS



=cut


=head1 METHODS FOR SUBCLASSING



=cut


=head1 PRIVATE METHODS



=cut






return 1;
