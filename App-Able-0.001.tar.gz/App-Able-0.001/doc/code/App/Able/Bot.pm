

package App::Able::Bot;


#UML_MODELER_BEGIN_PERSONAL_VARS_Bot

#UML_MODELER_END_PERSONAL_VARS_Bot

use App::Able::iBot;

use base qw(App::Able::iBot );



=head1 BOT



=cut


=head1 PUBLIC ATTRIBUTES

=pod 



=cut


=head1 PUBLIC METHODS



=cut


=head1 METHODS FOR SUBCLASSING



=cut


=head1 PRIVATE METHODS



=cut






return 1;
