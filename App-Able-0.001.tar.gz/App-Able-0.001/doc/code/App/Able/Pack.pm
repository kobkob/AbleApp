

package App::Able::Pack;


#UML_MODELER_BEGIN_PERSONAL_VARS_Pack

#UML_MODELER_END_PERSONAL_VARS_Pack

use App::Able::Bot;



=head1 PACK



=cut


=head1 PUBLIC ATTRIBUTES

=pod 



=cut


=head1 PUBLIC METHODS



=cut


=head1 METHODS FOR SUBCLASSING



=cut


=head1 PRIVATE METHODS



=cut






return 1;
