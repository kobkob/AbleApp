

package App::Able::Dev;


#UML_MODELER_BEGIN_PERSONAL_VARS_Dev

#UML_MODELER_END_PERSONAL_VARS_Dev

use App::Able::Create;
use App::Able::Verify;
use App::Able::Pack;
use App::Able::Plan;



=head1 DEV



=cut


=head1 PUBLIC ATTRIBUTES

=pod 



=cut


=head1 PUBLIC METHODS



=cut


=head1 METHODS FOR SUBCLASSING



=cut


=head1 PRIVATE METHODS



=cut






return 1;
