

package App::Able::Create;


#UML_MODELER_BEGIN_PERSONAL_VARS_Create

#UML_MODELER_END_PERSONAL_VARS_Create

use App::Able::Bot;



=head1 CREATE



=cut


=head1 PUBLIC ATTRIBUTES

=pod 



=cut


=head1 PUBLIC METHODS



=cut


=head1 METHODS FOR SUBCLASSING



=cut


=head1 PRIVATE METHODS



=cut






return 1;
