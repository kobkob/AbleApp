

package App::Able::Verify;


#UML_MODELER_BEGIN_PERSONAL_VARS_Verify

#UML_MODELER_END_PERSONAL_VARS_Verify

use App::Able::Bot;



=head1 VERIFY



=cut


=head1 PUBLIC ATTRIBUTES

=pod 



=cut


=head1 PUBLIC METHODS



=cut


=head1 METHODS FOR SUBCLASSING



=cut


=head1 PRIVATE METHODS



=cut






return 1;
