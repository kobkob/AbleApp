

package App::Able::Plan;


#UML_MODELER_BEGIN_PERSONAL_VARS_Plan

#UML_MODELER_END_PERSONAL_VARS_Plan




=head1 PLAN



=cut


=head1 PUBLIC ATTRIBUTES

=pod 



=cut


=head1 PUBLIC METHODS



=cut


=head1 METHODS FOR SUBCLASSING



=cut


=head1 PRIVATE METHODS



=cut






return 1;
