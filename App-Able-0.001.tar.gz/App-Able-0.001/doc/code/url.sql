
--
-- TABLE: URL
-- 
--  

CREATE TABLE URL (
);
