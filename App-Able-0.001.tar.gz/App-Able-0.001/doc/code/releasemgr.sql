
--
-- TABLE: ReleaseMgr
-- 
--  

CREATE TABLE ReleaseMgr (
);
