
--
-- TABLE: Release
-- 
--  

CREATE TABLE Release (
  id long int NOT NULL
);
