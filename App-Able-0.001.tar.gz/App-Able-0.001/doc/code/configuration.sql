
--
-- TABLE: Configuration
-- 
--  

CREATE TABLE Configuration (
  id long int NOT NULL
);

