
--
-- TABLE: Package
-- 
--  

CREATE TABLE Package (
);
ALTER TABLE Package ADD CONSTRAINT  FOREIGN KEY () REFERENCES Project ();
