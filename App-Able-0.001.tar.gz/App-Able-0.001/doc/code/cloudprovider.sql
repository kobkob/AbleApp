
--
-- TABLE: CloudProvider
-- 
--  

CREATE TABLE CloudProvider (
);
