
--
-- TABLE: Verification
-- 
--  

CREATE TABLE Verification (
  id long int NOT NULL
);
