
--
-- TABLE: ConfigMgr
-- 
--  

CREATE TABLE ConfigMgr (
);
