

package ::Bot;


#UML_MODELER_BEGIN_PERSONAL_VARS_Bot

#UML_MODELER_END_PERSONAL_VARS_Bot

use ::iBot;

use base qw(::iBot );



=head1 BOT



=cut


=head1 PUBLIC ATTRIBUTES

=pod 



=cut


=head1 PUBLIC METHODS



=cut


=head1 METHODS FOR SUBCLASSING



=cut


=head1 PRIVATE METHODS



=cut






return 1;
