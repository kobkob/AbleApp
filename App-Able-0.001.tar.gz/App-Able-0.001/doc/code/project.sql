
--
-- TABLE: Project
-- 
--  

CREATE TABLE Project (
  id long int NOT NULL ,
);
