
--
-- TABLE: Machine
-- 
--  

CREATE TABLE Machine (
);
