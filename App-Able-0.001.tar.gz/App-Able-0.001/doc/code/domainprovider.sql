
--
-- TABLE: DomainProvider
-- 
--  

CREATE TABLE DomainProvider (
);
