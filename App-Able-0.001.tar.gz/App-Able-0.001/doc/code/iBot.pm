

package ::iBot;


#UML_MODELER_BEGIN_PERSONAL_VARS_iBot

#UML_MODELER_END_PERSONAL_VARS_iBot




=head1 IBOT



=cut

=head1 ABSTRACT CLASS

=cut

=head1 PUBLIC METHODS



=cut


=head1 METHODS FOR SUBCLASSING



=cut


=head1 PRIVATE METHODS



=cut






return 1;
