
--
-- TABLE: HubProvider
-- 
--  

CREATE TABLE HubProvider (
);
