
--
-- TABLE: PackMgr
-- 
--  

CREATE TABLE PackMgr (
);
