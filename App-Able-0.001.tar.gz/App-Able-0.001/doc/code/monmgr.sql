
--
-- TABLE: MonMgr
-- 
--  

CREATE TABLE MonMgr (
);
