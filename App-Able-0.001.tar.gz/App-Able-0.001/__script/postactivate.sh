
mkdir -p $npm_config_root/.jsan
cp -r ./lib/* $npm_config_root/.jsan      

