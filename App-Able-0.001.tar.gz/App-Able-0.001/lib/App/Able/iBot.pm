package App::Able::iBot;

use strict;

=head1 IBOT



=cut

=head1 ABSTRACT CLASS

=cut

=head1 PUBLIC METHODS



=cut


=head1 METHODS FOR SUBCLASSING



=cut


=head1 PRIVATE METHODS



=cut






return 1;
